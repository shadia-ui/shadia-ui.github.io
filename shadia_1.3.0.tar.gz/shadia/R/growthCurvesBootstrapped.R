# library(fishmethods)
# data(fish)
# # ctjuvs <- fish[fish$Age < 3, ]
# # 
# # fish <- read.csv('fish_merrimack.csv')
# # 
# # fish <- rbind(ctjuvs[ ,1:3], fish[ ,2:4])
# # 
# roes <- fish[fish$Sex=='R', ]
# bucks <- fish[fish$Sex=='B', ]
# # 
# # 
# nruns <- 100
# 
# 
# # Bootstrap von Bertalanffy growth model parameters
# # for roes
# r.pars <- vector(mode='list', length=nruns)
# 
# pb <- txtProgressBar(min = 0, max = nruns, style = 3, char = '+')
# 
# for(i in 1:nruns){
# 
#   attempt <- 0
#   while(is.null(r.pars[[i]])){
#     attempt <- attempt + 1
#     try(
#       {samp <- roes[sample(nrow(roes), 1000),];
#       r.mod <- growth(size = samp$Length,
#                       age = samp$Age,
#                       Sinf = 600,
#                       K = .35,
#                       t0 = -1,
#                       error = 1,
#                       graph = FALSE
#                       )}
#     )
#     r.pars[[i]] <- data.frame(summary(r.mod$vout)$parameters)
#   }
# 
# 
# 
#   Sys.sleep(0.0001) # System time-out for update
#   setTxtProgressBar(pb, i)
# 
# }
# 
# close(pb)
# 
# 
# # Bootstrap von Bertalanffy growth model parameters
# # for bucks
# b.pars <- vector(mode='list', length=nruns)
# 
# pb <- txtProgressBar(min = 0, max = nruns, style = 3, char = '+')
# 
# for(i in 1:nruns){
# 
#   attempt <- 0
#   while(is.null(b.pars[[i]])){
#     attempt <- attempt + 1
#     try(
#       {samp <- bucks[sample(nrow(bucks), 1000),];
#       b.mod <- growth(size = samp$Length,
#                       age = samp$Age,
#                       Sinf = 600,
#                       K = .35,
#                       t0 = -1,
#                       error = 1,
#                       graph = FALSE
#                       )}
#     )
#     b.pars[[i]] <- data.frame(summary(b.mod$vout)$parameters)
#   }
# 
# 
# 
#   Sys.sleep(0.0001) # System time-out for update
#   setTxtProgressBar(pb, i)
# 
# }
# 
# close(pb)
# # 
# # 
# # b.parms_merrimack <- b.pars
# # r.parms_merrimack <- r.pars
# # 
# # save(b.parms_merrimack, file='data/b.parms_merrimack.rda')
# # save(r.parms_merrimack, file='data/r.parms_merrimack.rda')
