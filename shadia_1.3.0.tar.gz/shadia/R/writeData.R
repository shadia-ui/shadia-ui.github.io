#' @title Write simulation results
#' 
#' @description Internal function used to collect and
#' return all model inputs and relevant model
#' outputs (e.g., population size) from all k iterations 
#' of n years to the temporary environment 
#' in \code{\link{penobscotRiverModel}}, 
#' \code{\link{merrimackRiverModel}}, and
#' \code{\link{connecticutRiverModel}}.
#' 
#' Not intended to be called directly, but visible 
#' nonetheless.
#' 
#' @return A list of results.
#' 
#' @export
#' 
writeData <- function(){

# DATA WRITE ----
# Post-simulation data manipulation
if (.shadia$useTictoc) {
  tic("data write")
}

# Unlist and stack proportion of repeat spawners in each age for writing
pRepeats <- do.call("rbind", lapply(pRepeats, unlist))
colnames(pRepeats) <- paste('pRepeat_', colnames(pRepeats), sep = '')

# Unlist and stack upstream passage times
times <- do.call("rbind", lapply(ptime, unlist))
colnames(times) <- paste('timing_', 1:length(timely), sep = '')

# Unlist and stack age-structured spawning population into a useable output
spawners <- do.call("rbind", lapply(spawners, unlist))
colnames(spawners) <- paste(colnames(spawners), 'N', sep = '_')

# Rescale population size based on reduction factor at start of script
populationSize <- populationSize

if(river=='penobscot'){
# Collect inputs and outputs into a single object for file write
res <- data.frame(
  years,
  times,
  #OrUp,
  #StUp,
  #GilmUp,
  MdUp,
  HdUp,
  WEnfUp,
  BMillUp,
  MooseUp,
  GuilfUp,
  MattUp,
  OrD,
  StD,
  #GilmD,
  MdD,
  HdD,
  WEnfD,
  BMillD,
  MooseD,
  GuilfD,
  MattD,
  F.inRiver,
  F.commercial,
  F.bycatch,
  indirectM,
  latentM,
  pRepeats,
  ceiling(populationSize),
  ceiling(LowerPop),
  #OronoPop,
  #StillwaterPop,
  ceiling(MilfordPop),
  ceiling(EnfieldPop),
  ceiling(WeldonPop),
  ceiling(HowlandPop),
  ceiling(MoosePop),
  ceiling(BrownsPop),
  ceiling(GuilfordPop)#,
)

names(res)<-c(
  "year",
  "time_milford",
  "time_howland",
  "time_westenfield",
  "time_brownsmill",
  "time_moosehead",
  "time_guilford",
  "time_weldon",
  #"orono_up",
  #"stillwater_up",
  #"gilman_up",
  "milford_up",
  "howland_up",
  "westenfield_up",
  "brownsmill_up",
  "moosehead_up",
  "guilford_up",
  "weldon_up",
  "orono_down",
  "stillwater_down",
  #"gilman_down",
  "milford_down",
  "howland_down",
  "westenfield_down",
  "brownsmill_down",
  "moosehead_down",
  "guilford_down",
  "weldon_down",
  "inriverF",
  "commercialF",
  "bycatchF",
  "indirect",
  "latent",
  "pRepeat_Age1",
  "pRepeat_Age2",
  "pRepeat_Age3",
  "pRepeat_Age4",
  "pRepeat_Age5",
  "pRepeat_Age6",
  "pRepeat_Age7",
  "pRepeat_Age8",
  "pRepeat_Age9",
  "populationSize",
  "N_pu1A2A",
  #"N_pu1C",
  #"N_pu2C",
  "N_pu3A",
  "N_pu4A",
  "N_pu5A",
  "N_pu1B",
  "N_pu2B",
  "N_pu3B",
  "N_pu4B"
)


# Collect variables for sensitivity analysis and save them out
sens = data.frame(
  pStillUP,
  pStillD,
  pPiscUP,
  S.downstream,
  S.marine,
  popStart,
  p.female,
  S.prespawnM,
  S.postspawnM,
  S.prespawnF,
  S.postspawnF,
  S.juvenile,
  t.stoch,
  # t.RegrInt,
  # t.RegrSlp,
  # b.ArrRegrInt,
  # b.ArrRegrSlp,
  # r.ArrRegrInt,
  # r.ArrRegrSlp,
  b.Arr,
  r.Arr,
  ATUspawn1,
  ATUspawn2,
  Dspawn1,
  Dspawn2,
  linF,
  kF,
  t0F,
  linM,
  kM,
  t0M,
  # lwF.alpha,
  # lwF.beta,
  # lwM.alpha,
  # lwM.beta,
  b.length,
  r.length,
  spawnInt,
  batchSize,
  RAF,
  s.Optim,
  d.Max,
  tortuosity,
  motivation,
  daily.move,
  habStoch#,
  # scalarVar,
  # scen
)

return(list(		
  res	= res,
  sens = sens
))	
}

if(river=='merrimack'){
# Collect inputs and outputs into a single object for file write
res <- data.frame(
  years,
  times,
  EssUp,
  PawBUp,  
  PawUp,
  AmosUp,
  HookUp,
  EssD,
  PawBD,
  PawD,
  AmosD,
  HookD,
  pBypassUS,
  pBypassDS,
  F.inRiver,
  F.commercial,
  F.bycatch,
  indirectM,
  latentM,
  pRepeats,
  ceiling(populationSize),
  ceiling(popI),
  ceiling(popII),
  ceiling(popIII),
  ceiling(popIV),
  ceiling(popV)
)

names(res)<-c(
  "year",
  "time_essex",
  "time_pawBypass",
  "time_pawtucket",
  "time_amoskeag",
  "time_hookset",
  "EssexUp",
  "PawtucketBypassUp",
  "PawtucketUp",
  "AmoskeagUp",
  "HooksetUp",
  "EssexD",
  "PawtucketBypassD",
  "PawtucketD",
  "AmoskeagD",
  "HooksetD",
  "pBypassUp",
  "pBypassD",
  "inriverF",
  "commercialF",
  "bycatchF",
  "indirect",
  "latent",
  "pRepeat_Age1",
  "pRepeat_Age2",
  "pRepeat_Age3",
  "pRepeat_Age4",
  "pRepeat_Age5",
  "pRepeat_Age6",
  "pRepeat_Age7",
  "pRepeat_Age8",
  "pRepeat_Age9",
  "pRepeat_Age10",  
  "pRepeat_Age11",  
  "populationSize",
  "N_I",
  "N_II",
  "N_III",
  "N_IV",
  "N_V"
)

# Collect variables for sensitivity analysis and save them out
sens = data.frame(
  S.downstream,
  S.marine,
  popStart,
  p.female,
  S.prespawnM,
  S.postspawnM,
  S.prespawnF,
  S.postspawnF,
  S.juvenile,
  t.stoch,
  b.Arr,
  r.Arr,
  ATUspawn1,
  ATUspawn2,
  Dspawn1,
  Dspawn2,
  linF,
  kF,
  t0F,
  linM,
  kM,
  t0M,
  b.length,
  r.length,
  spawnInt,
  batchSize,
  RAF,
  s.Optim,
  d.Max,
  tortuosity,
  motivation,
  daily.move,
  habStoch
)

return(list(		
  res	= res,
  sens = sens
))	
}

if(river=='connecticut'){
# Collect inputs and outputs into a single object for file write
res <- data.frame(
  years,
  times,
  pSpill,
  HolUp,
  CabUp,
  SpillUp,
  GateUp,
  VernUp,
  HolD,
  CabD,
  GateD,
  VernD,
  NorthFieldV,
  NorthFieldT,
  NorthFieldVa,
  NorthFieldTa,
  F.inRiver,
  F.commercial,
  F.bycatch,
  indirectM,
  latentM,
  pRepeats,
  ceiling(populationSize),
  ceiling(popI),
  ceiling(popII),
  ceiling(popIII),
  ceiling(popIV),
  ceiling(popV)
)

names(res)<-c(
  "year",
  "time_holyoke",
  "time_cabot",
  "time_spillway",
  "time_gatehouse",
  "time_vernon",
  "pSpill",
  "HolyokeUp",
  "CabotUp",
  "SpillwayUp",
  "GatehouseUp",
  "VernonUp",
  "HolyokeD",
  "CabotD",
  "GatehouseD",
  "VernonD",
  "NorthFieldV",
  "NorthFieldT",
  "NorthFieldVa",
  "NorthFieldTa",
  "inriverF",
  "commercialF",
  "bycatchF",
  "indirect",
  "latent",
  "pRepeat_Age1",
  "pRepeat_Age2",
  "pRepeat_Age3",
  "pRepeat_Age4",
  "pRepeat_Age5",
  "pRepeat_Age6",
  "pRepeat_Age7",
  "pRepeat_Age8",
  "populationSize",
  "N_I",
  "N_II",
  "N_III",
  "N_IV",
  "N_V"
)

# Collect variables for sensitivity analysis and save them out
sens = data.frame(
  S.downstream,
  S.marine,
  popStart,
  p.female,
  S.prespawnM,
  S.postspawnM,
  S.prespawnF,
  S.postspawnF,
  S.juvenile,
  t.stoch,
  b.Arr,
  r.Arr,
  ATUspawn1,
  ATUspawn2,
  Dspawn1,
  Dspawn2,
  linF,
  kF,
  t0F,
  linM,
  kM,
  t0M,
  b.length,
  r.length,
  spawnInt,
  batchSize,
  RAF,
  s.Optim,
  d.Max,
  tortuosity,
  motivation,
  daily.move,
  habStoch
)

return(list(		
  res	= res,
  sens = sens
))	

}

if(river=='susquehanna'){
# Collect inputs and outputs into a single object for file write
res <- data.frame(
  years = years,  
  populationSize = populationSize,
  LowPop = LowPop,
  ConPop = ConPop,
  HolPop = HolPop,
  SafPop = SafPop,
  YorPop = YorPop,
  SunPop = SunPop,
  JunPop = JunPop,
  WesPop = WesPop,
  WilPop = WilPop,
  LocPop = LocPop,
  ChePop = ChePop,
  ChaPop = ChaPop,
  NorPop = NorPop,
  RocPop = RocPop,
  UnaPop = UnaPop,  
  ColPop = ColPop,
  ConUp = ConUp,
  HoltUp = HoltUp,
  SafeUp = SafeUp,
  YorkUp = YorkUp,
  SunUp = SunUp,
  WillUp = WillUp,
  ChasUp = ChasUp,
  LockUp = LockUp,
  RockUp = RockUp,
  CollUp = CollUp,
  ConD = ConD,
  HoltD = HoltD,
  SafeD = SafeD,
  YorkD = YorkD,
  SunD = SunD,
  WillD = WillD,
  LockD = LockD,
  ChasD = ChasD,
  RockD = RockD,
  CollD = CollD,
  times = times,
  F.inRiver = F.inRiver,
  F.commercial = F.commercial,
  F.bycatch = F.bycatch,
  indirectM = indirectM,
  latentM = latentM,
  pRepeats
)


names(res)<-c(
  'year',
  'populationSize',
  'N_1A',
  'N_2A',
  'N_3A',
  'N_4A',
  'N_5A',
  'N_6A',
  'N_1B',
  'N_1C',
  'N_2C',
  'N_3C',
  'N_1D',
  'N_2D',
  'N_7A',
  'N_8A',
  'N_9A',
  'N_10A',
  'ConowingoUp',
  'HoltwoodUp',
  'SafeHarborUp',
  'YorkHavenUp',
  'SunburyUp',
  'WilliamsportUp',
  'ChaseHibbardUp',
  'LockHavenUp',
  'RockBottomUp',
  'ColliersvilleUp',
  'ConowingoD',
  'HoltwoodD',
  'SafeHarborD',
  'YorkHavenD',
  'SunburyD',
  'WilliamsportD',
  'LockHavenD',
  'ChaseHibbardD',
  'RockBottomD',
  'ColliersvilleD',
  'time_conowingo',
  'time_holtwood',
  'time_safeharbor',
  'time_yorkhaven',
  'time_sunbury',
  'time_williamsport',
  'time_lockhaven',
  'time_chasehibbard',
  'time_rockbottom',
  'time_colliersville',
  "inriverF",
  "commercialF",
  "bycatchF",
  "indirect",
  "latent",
  "pRepeat_Age1",
  "pRepeat_Age2",
  "pRepeat_Age3",
  "pRepeat_Age4",
  "pRepeat_Age5",
  "pRepeat_Age6",
  "pRepeat_Age7",
  "pRepeat_Age8",
  "pRepeat_Age9",
  "pRepeat_Age10",
  "pRepeat_Age11"
)

# Collect variables for sensitivity analysis and save them out
sens = data.frame(
  pJuniataUp = pJuniataUp,
  pWestBranchUp = pWestBranchUp,
  pChemungUp = pChemungUp,
  pNorthBranchUp = pNorthBranchUp,
  S.downstream = S.downstream,
  S.marine = S.marine,
  popStart = popStart,
  p.female = p.female,
  S.prespawnM = S.prespawnM,
  S.postspawnM = S.postspawnM,
  S.prespawnF = S.prespawnF,
  S.postspawnF = S.postspawnF,
  S.juvenile = S.juvenile,
  t.stoch = t.stoch,
  b.Arr = b.Arr,
  r.Arr = r.Arr,
  ATUspawn1 = ATUspawn1,
  ATUspawn2 = ATUspawn2,
  Dspawn1 = Dspawn1,
  Dspawn2 = Dspawn2,
  linF = linF,
  kF = kF,
  t0F = t0F,
  linM = linM,
  kM = kM,
  t0M = t0M,
  b.length = b.length,
  r.length = r.length,
  spawnInt = spawnInt,
  batchSize = batchSize,
  RAF = RAF,
  s.Optim = s.Optim,
  d.Max = d.Max,
  tortuosity = tortuosity,
  motivation = motivation,
  daily.move = daily.move,
  habStoch = habStoch
)

return(list(		
  res	= res,
  sens = sens
))	
}

if(river=='saco'){
  # Collect inputs and outputs into a single object for file write
  res <- data.frame(
    years,
    times,
    CataractUp,
    SpringsBradburyUp,  
    SkeltonUp,
    BarMillsUp,
    WestBuxtonUp,
    BonnyEagleUp,
    CataractD,
    SpringsBradburyD,  
    SkeltonD,
    BarMillsD,
    WestBuxtonD,
    BonnyEagleD,
    F.inRiver,
    F.commercial,
    F.bycatch,
    indirectM,
    latentM,
    pRepeats,
    ceiling(populationSize),
    ceiling(popI),
    ceiling(popII),
    ceiling(popIII),
    ceiling(popIV),
    ceiling(popV),
    ceiling(popVI),    
    ceiling(popVII)   
  )
  
  names(res)<-c(
    "year",
    "time_Cataract",
    "time_SpringsBradbury",
    "time_Skelton",
    "time_BarMills",
    "time_WestBuxton",
    "time_BonnyEagle",
    "CataractUp",
    "SpringsBradburyUp",
    "SkeltonUp",
    "BarMillsUp",
    "WestBuxtonUp",
    "BonnyEagleUp",
    "CataractD",
    "SpringsBradburyD",
    "SkeltonD",
    "BarMillsD",
    "WestBuxtonD",
    "BonnyEagleD",
    "inriverF",
    "commercialF",
    "bycatchF",
    "indirect",
    "latent",
    "pRepeat_Age1",
    "pRepeat_Age2",
    "pRepeat_Age3",
    "pRepeat_Age4",
    "pRepeat_Age5",
    "pRepeat_Age6",
    "pRepeat_Age7",
    "pRepeat_Age8",
    "pRepeat_Age9",
    "populationSize",
    "N_I",
    "N_II",
    "N_III",
    "N_IV",
    "N_V",
    "N_VI",
    "N_VII"
  )
  
  # Collect variables for sensitivity analysis and save them out
  sens = data.frame(
    S.downstream,
    S.marine,
    popStart,
    p.female,
    S.prespawnM,
    S.postspawnM,
    S.prespawnF,
    S.postspawnF,
    S.juvenile,
    t.stoch,
    b.Arr,
    r.Arr,
    ATUspawn1,
    ATUspawn2,
    Dspawn1,
    Dspawn2,
    linF,
    kF,
    t0F,
    linM,
    kM,
    t0M,
    b.length,
    r.length,
    spawnInt,
    batchSize,
    RAF,
    s.Optim,
    d.Max,
    tortuosity,
    motivation,
    daily.move,
    habStoch
  )
  
  return(list(		
    res	= res,
    sens = sens
  ))	
}

# Write the inputs and outputs to a text file that can be read into R
# writeData(filename)
  if (.shadia$useTictoc) {
    toc() #("data write")
  }

}