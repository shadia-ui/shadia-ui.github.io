library(plyr)
library(MASS)
library(geosphere)
library(lubridate)
library(zoo)
library(Rcpp)
#source('R/definePassageRates.R')
#Rcpp::sourceCpp('src/pnrCppFuns.cpp')

nRuns = 1
nYears = 10
timing = list(1,1,1,1,1,1)
upstream = list(
  cataract = 1,
  spring = 1,
  skelton = 1,
  barmills = 1,
  westBuxton = 1,
  bonnyEagle = 1
)
downstream = list(
  cataract = 1,
  spring = 1,
  barmills=1,
  skelton = 1,
  westBuxton = 1,
  bonnyEagle = 1
)
inRiverF = 0
commercialF = 0
bycatchF = 0
indirect = 1
latent = 1
watershed = TRUE

k = 1
n = 1

# Assign River
river <- 'saco'

# Passage variable assignment -----
pDraws <- upstream
dDraws <- downstream

# For watershed applications of
# the model, all values need to
# match
sampU <- sample(pDraws[[1]], 1)
pDraws <- lapply(pDraws, 
                 function(x){
                   if(watershed){
                     x <- sampU}
                   else
                   {x <- x}
                 }
)
sampD <- sample(dDraws[[1]], 1)
dDraws <- lapply(dDraws, 
                 function(x){
                   if(watershed){
                     x <- sampD}
                   else
                   {x <- x}
                 }
)

# Set parameters -----
list2env(setParameters())


# Data load and memory pre-allocation -----

list2env(setUpData())

list2env(defineOutputVectors())

# Hydro system configuration -----
list2env(defineHydroSystem())
list2env(defineHabitat())

# OUTER LOOP -----
# Outer loop for number of simulations- 
# this is how many runs it will do
  .shadia$k <- k

    list2env(outerLoopSampling(), envir = .shadia)

  
  # . Dam passage efficiencies -----
  list2env(definePassageRates())
  
  # . Upstream passage efficiencies and migration route -----
  # NOTE: This section is special for the PNR because of multiple routes with
  # unequal numbers of dams and unequal reach lengths
  list2env(annualUpstream())
  
  # . In-river fishing mortality
  # Define in-river fishing mortalities for 
  # each PU in each of the four
  # possible migration routes
  list2env(fwFishingMort())
  
  # Starting population structure -----
  # Define starting population structure for each simulation
  list2env(startingPop())
    
    # Assign iterator to a var so it
    # can be accessed in functions called
    .shadia$n <- n
 
    list2env(weldonScenarios())
    
    # Reset the scalar based on population size
    list2env(setScalar())
    
    # Scale the population
    list2env(scalePop())
    

    # JMS: Perform sampling and save variables 
    # for the inner-loop ONE TIME, for repeatability
    # otherwise load the variables we saved...
      list2env(innerLoopSampling())

    # . Process fish and eggs ----
    # Processing of populations generalized and
    # moved into functions. See defineFunctions.R
    # JMS Dec 2017
  
    # Make matrices to hold fish
    list2env(populationMatrices())
    
    # Fill them in and change them into cohorts
    list2env(processCohorts())
    
    
    # . Downstream migration -----
    #if (useTictoc) toc() 
    # Post-spawning mortality
    list2env(postSpawnMortality())
    
    # Define downstream migration survival rate matrices
    # and then apply them to calculate the number of adult
    # and juvenile fish surviving to the ocean.
    list2env(downstreamMigration())
    
    
    # . The next generation -----
    # next year (after applying ocean survival)
    list2env(nextGeneration())

    # . Store output in pre-allocated vectors -----
    list2env(fillOutputVectors())

# Write the simulation results to an object
# that can be returned to workspace
writeData()