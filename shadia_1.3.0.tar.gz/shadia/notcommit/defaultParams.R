library(plyr)
library(MASS)
library(geosphere)
library(lubridate)
library(zoo)
library(Rcpp)
#source('R/definePassageRates.R')
#Rcpp::sourceCpp('src/pnrCppFuns.cpp')

  nRuns = 1
  nYears = 10
  timing = list(1,1,1,1,1,1,1)
  upstream = list(
    cataract = 1,
    springIsle = 1,
    skelton = 1,
    westBuxton = 1,
    bonnyEagle = 1
  )
  downstream = list(
    cataract = 1,
    springIsle = 1,
    skelton = 1,
    westBuxton = 1,
    bonnyEagle = 1
  )
  inRiverF = 0
  commercialF = 0
  bycatchF = 0
  indirect = 1
  latent = 1
  watershed = TRUE
  
  k = 1
  n = 1