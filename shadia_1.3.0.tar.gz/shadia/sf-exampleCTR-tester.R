# Parallel execution on a local cluster
# -------------------------------------------------------------------------
  
# R snowfall example

# Load R packages
  library(snowfall)
  library(rlecuyer)
  library(shadia)

# 1. Initialization of snowfall.
# -----  
# Initialize parallel mode using sockets and
# command-line args
sfInit(parallel=TRUE, cpus=3, type="SOCK")

# Display information about nodes and processes
# used by this job. This is entirely optional,
# to demonstrate snowfall methods sfClusterCall()
# and sfCpus().

# Describe the nodes and cpus:
cat(paste0('CPU count: ', sfCpus()), fill=TRUE)

# Count off each process with anonymous function
cat('CPU ids: ', unlist(sfClusterCall(function() Sys.getpid())), fill=TRUE)

# 2. Load data. 
# -----
data('fish')
data('arr.B')
data('arr.R')
data('b.parms')
data('r.parms')
data('tempD')
data('tempData_connecticut')

# 3. Define wrapper function, which can be called in parallel.
#
#   Runs merrimackRiverModel() on each worker
#
#   Here, workerId just contains the identity of the cpu that perfomed
#   the work. We do this only to prove we have used all the specified cpus!
#   Ideally, we will minimize the data sent to (and returned from) the workers.
#
#   Note that constructing and returning a list enables the function to
#   return more than one output.
# -----
wrapper <- function(idx) {

# Get cpu ids  
  workerId <- paste(Sys.info()[['nodename']],
                    Sys.getpid(),
                    sep='-'
                    )
# Sample timing
times <- sample(c(1,2,3),1)  

# Run the model
res1 <- connecticutRiverModel(
  nRuns = 1,
  nYears = 40,
  timing = list(times, times, times, times, times),
  upstream = list(
    holyoke = c(0.50, 0.60, 0.70),
    cabot = 1,
    spillway = 1,
    gatehouse = 1,
    vernon = 1
  ),
  downstream = list(
    holyoke = c(0.80, 0.90, 0.95),
    cabot = 1,
    gatehouse= 1,
    vernon = 1
  ),
  northfield = list(
    turnersA = 0.95,
    turnersJ = 0.95,
    vernonA = 0.95,
    vernonJ = 0.95
  ),
  pSpillway = 1,
  inRiverF = 0,
  commercialF = 0,
  bycatchF = 0,
  indirect = 1,
  latent = 1,
  watershed = TRUE
  )

# Define the output lists
    retlist <- list(
      worker=workerId,
      sim=res1)   
    return(retlist)
}

# 4. Export needed data to workers 
#    load required packages on workers.
# -----
sfLibrary(shadia)

# 5. Start network random number generator 
#    (as "sample" uses random numbers).
# -----
#sfClusterSetupRNG()

# 6. Distribute calculation to workers
# -----
niterations <- 3
start <- Sys.time()

# The magic is in snowfall's sfLapply() function,
# which sends wrapper() out to the workers:
result <- sfLapply(1:niterations, wrapper) 

Sys.time()-start

# 7. Stop snowfall
# -----
sfStop()

# 8. Examine the results returned from the cluster:
# -----

# 'result' is a list of lists. Save this:
save(result, file = "snowfall-result.rda")

# Extract results list from output list
out <- lapply(result, function(x) x[[c('sim')]])

# Extract user inputs and population metrics
res <- lapply(out, function(x) x[[c('res')]])
resdf <- do.call(rbind, res)

# Extract sensitivity variables
sens <- lapply(out, function(x) x[[c('sens')]])
sensdf <- do.call(rbind, sens)

# Plot results as line graph
# plotter <- plyr::ddply(resdf[resdf$year>=3,], 'year', plyr::summarize,
#                  pop=mean(populationSize),
#                  lci=CI(populationSize)[1],
#                  uci=CI(populationSize)[2]
#                  )
# plot(x=plotter$year, y=plotter$pop, type = 'l', col='gray40',
#      yaxt='n', xlab='Years', ylab='Spawner abundance (millions)',
#      ylim=c(0,5e6))
# par(mar=c(5,5,1,1))
# lines(plotter$year, plotter$lci, col='gray60', lty=2)
# lines(plotter$year, plotter$uci, col='gray60', lty=2)
# axis(2, at=seq(0,5e6,.5e6), labels = format(seq(0, 5, 0.5), digits=2),
#      las=2)
# 
# # Boxplot of PU-specific population sizes
# bb <- boxplot(resdf[resdf$year>=35,(ncol(resdf)-4):ncol(resdf)],
#         outline=FALSE, col='gray87', ylim=c(0,1.5e6),
#         col.axis='white', notch=FALSE, plot=FALSE)
#   # Replace stats for whiskers with 95% CI
#   bb$stats[c(1,5), ] <- apply(
#     resdf[resdf$year>=35,(ncol(resdf)-4):ncol(resdf)],
#     2,
#     quantile,
#     probs=c(.025, 0.975), na.rm = TRUE
#     )
#   # Re-plot
#   bxp(bb, outline=FALSE, ylim=c(0,1.5e6),
#       boxfill='gray87', col.axis='white',
#       staplewex=0, whisklty=1, whiskcol='gray40',
#       whisklwd=2, boxcol='gray40', boxlwd=2,
#       medcol='gray40')
#   # Add x (side=1) and y (side=2) axes
#   axis(side=1, at=seq(1,5,1), labels = c('I', 'II', 'III', 'IV', 'V'))
#   axis(side=2, las=2, at=seq(0,1.5e6,.25e6),
#        labels=format(seq(0,1.5,.25), digits=2))
#   # Close it up with a box so axis styles match
#   box()
#   # Add axis labels
#   mtext(text='Spawners (millions)', side=2, line=3.5)
#   mtext(text='Production unit (PU)', side=1, line=3.5)
#   
# # Testing for TF relisencing, 58% rule  
# end = resdf[resdf$year>=35,(ncol(resdf)-4):ncol(resdf)]  
# check=((end[,4]+end[,5])/(end[,4]+end[,5]+end[,2]))  
# muCheck = mean(check)
# 
# par(mar=c(5,5,1,1))
# hist((end[,4]+end[,5])/(end[,4]+end[,5]+end[,2]),
#      col='gray40', main='', yaxt='n', xaxt='n',
#      xlab='Holyoke fish passing Turners Falls',
#      xlim=c(0,1)
#      )
# axis(side=2, pos=0)
# axis(side=1, pos=0)
# abline(v=muCheck, col='blue', lty=1, lwd=2)
# abline(v=quantile(check, probs=c(0.025, 0.975)),
#        col='red', lty=2, lwd=2)
# text(x=0.01, y=60, paste0('Mean = ', round(muCheck, 2)),
#      cex=1.1, adj=0)


